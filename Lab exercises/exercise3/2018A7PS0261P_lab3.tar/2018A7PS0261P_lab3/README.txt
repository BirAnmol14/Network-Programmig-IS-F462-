To Compile:
$make compile 
To Run:
$ ./fd_sharing <No. of Processes>