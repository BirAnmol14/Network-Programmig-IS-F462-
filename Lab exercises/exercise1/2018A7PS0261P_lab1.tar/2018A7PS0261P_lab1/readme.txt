To Compile:
$make compile
To Run:
$make run n=(desired value)
--can directly do make run