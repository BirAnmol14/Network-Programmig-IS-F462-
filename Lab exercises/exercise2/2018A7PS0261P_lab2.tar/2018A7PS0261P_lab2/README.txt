To Compile:
$make compile 
To Run:
$ ./select_epoll_test <No. of Processes>